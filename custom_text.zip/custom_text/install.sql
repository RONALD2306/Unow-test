CREATE TABLE IF NOT EXISTS `ps_custom_text` (
    `id_custom_text` int(11) NOT NULL AUTO_INCREMENT,
    `id_product` int(11) NOT NULL,
    `custom_text` text NOT NULL,
    PRIMARY KEY (`id_custom_text`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;