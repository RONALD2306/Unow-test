<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class Custom_text extends Module
{
    public function __construct()
    {
        $this->name = 'custom_text';
        $this->tab = 'front_office_features';
        $this->version = '1.0.0';
        $this->author = 'Ronald Espinoza';
        $this->need_instance = 0;

        parent::__construct();

        $this->displayName = $this->l('Texto personalizado');
        $this->description = $this->l('Permite agregar texto personalizado a cada producto.');
    }

    public function install()
    {
        if (!parent::install() ||
            !$this->registerHook('displayProductAdditionalInfo') ||
            !$this->createDatabaseTable()) {
            return false;
        }

        return true;
    }

    public function uninstall()
    {
        if (!parent::uninstall() || !$this->deleteDatabaseTable()) {
            return false;
        }

        return true;
    }

    public function createDatabaseTable()
    {
        $sql = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'custom_text` (
            `id_custom_text` int(11) NOT NULL AUTO_INCREMENT,
            `id_product` int(11) NOT NULL,
            `custom_text` text NOT NULL,
            PRIMARY KEY (`id_custom_text`)
        ) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8;';

        return Db::getInstance()->execute($sql);
    }

    public function deleteDatabaseTable()
    {
        $sql = 'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'custom_text`;';

        return Db::getInstance()->execute($sql);
    }

    public function hookDisplayProductAdditionalInfo($params)
    {
        $product = new Product($params['product']->id);
        $custom_text = $this->getCustomText($product->id);

        $this->context->smarty->assign('custom_text', $custom_text);

        return $this->display(__FILE__, 'views/front.tpl');
    }

    public function getCustomText($id_product)
    {
        $sql = 'SELECT custom_text FROM `' . _DB_PREFIX_ . 'custom_text` WHERE id_product = ' . (int)$id_product . ';';

        return Db::getInstance()->getValue($sql);
    }
}