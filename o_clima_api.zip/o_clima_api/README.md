# modulo-prestashop-o_clima_api
